//
//  KMTag.m
//  KMTag
//
//  Created by chavez on 2017/7/13.
//  Copyright © 2017年 chavez. All rights reserved.
//

#import "KMTag.h"
#define JCScrean_W ([UIScreen mainScreen].bounds.size.width)
@implementation KMTag

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.textAlignment = NSTextAlignmentCenter;
    }
    return self;
}

- (void)setupWithText:(NSString*)text {
    
    self.text = text;
//    self.textColor = [KMTools colorWithHexString:@"#999999"];
    self.textColor = [UIColor cyanColor];
    self.font = [UIFont systemFontOfSize:9];
    UIFont* font = self.font;
    
    CGSize size = [text sizeWithAttributes:@{NSFontAttributeName: font}];
    
    CGRect frame = self.frame;
    //这个是不规则的
//    frame.size = CGSizeMake(size.width + 40, size.height + 20);
    
    //规则的，固定长度的
//    CGFloat  labelWidth = (JCScrean_W - 80)/3;
//    CGFloat  labelWidth = 20;
    frame.size = CGSizeMake(size.width+10, size.height + 10);
    
    self.frame = frame;
//    self.backgroundColor = JCLightGray;
//    self.layer.cornerRadius = 5;
//    self.layer.borderColor = JCLightGray.CGColor;
//    self.layer.masksToBounds = YES;
//    self.layer.borderWidth = 1.0;
    
}



@end

//
//  ViewController.m
//  CubeTagsCloud
//
//  Created by 吴承炽 on 2018/2/8.
//  Copyright © 2018年 申丰科技. All rights reserved.
//

#import "ViewController.h"
#import "KMTagListView.h"

#define JCScrean_W ([UIScreen mainScreen].bounds.size.width)
#define JCScrean_H ([UIScreen mainScreen].bounds.size.height)
@interface ViewController ()
@property(nonatomic,strong)UIView * contentView;
@property (nonatomic, assign) CGPoint diceAngle;
@property (nonatomic, strong)NSArray<NSString *> *ItemImageArr;
@property (nonatomic, strong)NSMutableArray<UIView *> *ViewArr;

@property (nonatomic, assign)CGFloat angleX;
@property (nonatomic, assign)CGFloat angleY;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.angleX = 0.01;
    self.angleY = 0.01;
    self.view.backgroundColor = [UIColor whiteColor];
    [self builtMainView];
    [self builtCubeFrame];

    NSTimer * timer = [NSTimer timerWithTimeInterval:0.02 target:self selector:@selector(test3DAniMate) userInfo:nil repeats:YES];
    // 添加到runloop
    NSRunLoop *runLoop = [NSRunLoop currentRunLoop];
    [runLoop addTimer:timer forMode:NSDefaultRunLoopMode];
//    [self test3DAniMate];
}
-(void)test3DAniMate
{
    self.angleX += 0.01;
    self.angleY += 0.01;
    CATransform3D transform = CATransform3DIdentity;
    transform.m34 = -1 / 500;
    transform = CATransform3DRotate(transform, self.angleX, 0, 1, 0);
    transform = CATransform3DRotate(transform, self.angleY, 1, 0, 0);
    self.contentView.layer.sublayerTransform = transform;
}
-(void)builtMainView
{
    UIView * contentView = [[UIView alloc]initWithFrame:CGRectMake(0, (JCScrean_H - JCScrean_W)/2, JCScrean_W, JCScrean_W)];
    contentView.backgroundColor = [UIColor clearColor];
    self.contentView = contentView;
    [self.view addSubview:contentView];
}
-(void)builtCubeFrame
{
    self.ItemImageArr = @[@"宝剑国王",@"宝剑王后",@"宝剑骑士",@"宝剑侍从",@"宝剑十",@"宝剑九",@"宝剑八",@"宝剑七",@"宝剑六",@"宝剑五",@"宝剑四",@"宝剑三",@"宝剑二",@"宝剑A",@"金币国王",@"金币王后",@"金币骑士",@"金币侍从",@"金币十",@"金币九",@"金币八",@"金币七",@"金币六",@"金币五",@"金币四",@"金币三",@"金币二",@"金币A",@"权杖国王",@"权杖王后",@"权杖骑士",@"权杖侍从",@"权杖十",@"权杖九",@"权杖八",@"权杖七",@"权杖六",@"权杖五",@"权杖四",@"权杖三",@"权杖二",@"权杖A",@"圣杯国王",@"圣杯王后",@"圣杯骑士",@"圣杯侍从",@"圣杯十",@"圣杯九",@"圣杯八",@"圣杯七",@"圣杯六",@"圣杯五",@"圣杯四",@"圣杯三",@"圣杯二",@"圣杯A",@"倒掉者",@"恶魔",@"标签",@"程序",@"宝剑国王",@"宝剑王后",@"宝剑骑士",@"宝剑侍从",@"宝剑十",@"宝剑九",@"宝剑八",@"宝剑七",@"宝剑六",@"宝剑五",@"宝剑四",@"宝剑三",@"宝剑二",@"宝剑A",@"金币国王",@"金币王后",@"金币骑士",@"金币侍从",@"金币十",@"金币九",@"金币八",@"金币七",@"金币六",@"金币五",@"金币四",@"金币三",@"金币二",@"金币A",@"权杖国王",@"权杖王后",@"权杖骑士",@"权杖侍从",@"权杖十",@"权杖九",@"权杖八",@"权杖七",@"权杖六",@"权杖五",@"权杖四",@"权杖三",@"权杖二",@"权杖A",@"圣杯国王",@"圣杯王后",@"圣杯骑士",@"圣杯侍从",@"圣杯十",@"圣杯九",@"圣杯八",@"圣杯七",@"圣杯六",@"圣杯五",@"圣杯四",@"圣杯三",@"圣杯二",@"圣杯A",@"倒掉者",@"恶魔",@"标签",@"程序"];
    [self builtSixView];
    self.view.backgroundColor = [UIColor clearColor];
    self.contentView.backgroundColor = [UIColor clearColor];
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(viewTransform:)];
    [self.contentView addGestureRecognizer:pan];
    
    //add cube face 1
    CATransform3D diceTransform = CATransform3DIdentity;
    diceTransform = CATransform3DTranslate(diceTransform, 0, 0, 75);
    [self addFace:0 withTransform:diceTransform];
    
    //add cube face 2
    diceTransform = CATransform3DTranslate(CATransform3DIdentity, 75, 0, 0);
    diceTransform = CATransform3DRotate(diceTransform, M_PI_2, 0, 1, 0);
    [self addFace:1 withTransform:diceTransform];
    
    //add cube face 3
    //move this code after the setup for face no. 6 to enable button
    diceTransform = CATransform3DTranslate(CATransform3DIdentity, 0, -75, 0);
    diceTransform = CATransform3DRotate(diceTransform, M_PI_2, 1, 0, 0);
    [self addFace:2 withTransform:diceTransform];
    
    //add cube face 4
    diceTransform = CATransform3DTranslate(CATransform3DIdentity, 0, 75, 0);
    diceTransform = CATransform3DRotate(diceTransform, -M_PI_2, 1, 0, 0);
    [self addFace:3 withTransform:diceTransform];
    
    //add cube face 5
    diceTransform = CATransform3DTranslate(CATransform3DIdentity, -75, 0, 0);
    diceTransform = CATransform3DRotate(diceTransform, -M_PI_2, 0, 1, 0);
    [self addFace:4 withTransform:diceTransform];
    
    //add cube face 6
    diceTransform = CATransform3DTranslate(CATransform3DIdentity, 0, 0, -75);
    diceTransform = CATransform3DRotate(diceTransform, M_PI, 0, 1, 0);
    [self addFace:5 withTransform:diceTransform];
}
- (void)addFace:(NSInteger)index withTransform:(CATransform3D)transform
{
    //    NSLog(@"多少个标题：%zd",self.ItemImageArr.count);
    UIView * face = (UIView *)self.ViewArr[index];
    [self.contentView addSubview:face];
    CGSize containerSize = self.contentView.bounds.size;
    face.center = CGPointMake(containerSize.width / 2.0,
                              containerSize.height / 2.0);
    face.layer.transform = transform;
    face.layer.doubleSided = YES;
    NSMutableArray * arr = [[NSMutableArray alloc]init];
    switch (index) {
        case 0:
        {
            for (int i = 0; i <19; i++) {
                [arr addObject:self.ItemImageArr[i]];
            }
        }
            break;
        case 1:
        {
            for (int i = 20; i <39; i++) {
                [arr addObject:self.ItemImageArr[i]];
            }
        }
            break;
        case 2:
        {
            for (int i = 40; i <59; i++) {
                [arr addObject:self.ItemImageArr[i]];
            }
        }
            break;
        case 3:
        {
            for (int i = 60; i <79; i++) {
                [arr addObject:self.ItemImageArr[i]];
            }
        }
            break;
        case 4:
        {
            for (int i = 80; i <99; i++) {
                [arr addObject:self.ItemImageArr[i]];
            }
        }
            break;
        case 5:
        {
            for (int i = 100; i <119; i++) {
                [arr addObject:self.ItemImageArr[i]];
            }
        }
            break;
        default:
            break;
    }
    KMTagListView *tag = [[KMTagListView alloc]initWithFrame:CGRectMake(0, 0, 150, 0)];
    tag.backgroundColor = [UIColor clearColor];
    tag.delegate_ = self;
    [face addSubview:tag];
    [tag setupSubViewsWithTitles:arr];
    CGRect rect = tag.frame;
    rect.size.height = tag.contentSize.height;
    tag.frame = rect;
}

- (void)viewTransform:(UIPanGestureRecognizer *)sender
{
    CGPoint point = [sender translationInView:self.contentView];
    CGFloat angleX = self.diceAngle.x + (point.x/30);
    self.angleX = angleX;
    CGFloat angleY = self.diceAngle.y - (point.y/30);
    self.angleY = angleY;
    
    CATransform3D transform = CATransform3DIdentity;
    transform.m34 = -1 / 500;
    transform = CATransform3DRotate(transform, angleX, 0, 1, 0);
    transform = CATransform3DRotate(transform, angleY, 1, 0, 0);
    self.contentView.layer.sublayerTransform = transform;
    
    if (sender.state == UIGestureRecognizerStateEnded)
    {
        self.diceAngle = CGPointMake(angleX, angleY);
    }
//    [self test3DAniMate];
}

-(void)builtSixView
{
    for (int i = 0; i < 6; i++) {
        UIView * face = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 150, 150)];
        face.tag = i;
        face.backgroundColor = [UIColor clearColor];
        face.layer.borderWidth = 0.5f;
        face.layer.borderColor = [UIColor colorWithRed:192.0/255.0 green:192.0/255.0 blue:192.0/255.0 alpha:1.0].CGColor;
        //        face.alpha = 0.1;
        [self.ViewArr addObject:face];
    }
}
-(NSMutableArray<UIView *> *)ViewArr
{
    if (!_ViewArr) {
        _ViewArr = [[NSMutableArray<UIView *> alloc]init];
    }
    return _ViewArr;
}

@end
